﻿using System.ComponentModel.DataAnnotations;

namespace CRUDAJAX.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }

        [Required (ErrorMessage="Name  Cant  be  Blank ")]
        public string? Name { get; set; }
        [Required(ErrorMessage = "Email  Cant  be  Blank ")]
        public string? Email { get; set; }
        [Required(ErrorMessage = "City    Cant  be  Blank ")]
        public string? City { get; set; }
        
    
        // Add other properties as needed
    }
}
